<template>
  <NuxtRouteAnnouncer />
  <NuxtPage />
</template>
